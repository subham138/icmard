<script>
$(document).ready(function() {
    $('#example').DataTable();
} );	
</script>

	
<!--<script src="js/classie.js"></script>	-->



<script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
<script src="<?=base_url()?>assets/js/main_javascript.js"></script>
<script src="<?=base_url()?>assets/js/main_jquery.js"></script>
</body>
</html>
